TOKEN = '6561286995:AAG12YUPveu97Ks-rPv1sWvjIZ6IjB9KHTk'
admins = 1404494933
chat = -1001965151482

# Наш telegram форум https://na-sha.ru/